/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package farwas;

import static farwas.Kasir.txt_userkasir;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;
public class Pembelian extends javax.swing.JFrame {

    /**
     * Creates new form login
     */
    public Pembelian() {
        initComponents();
        Connect();
        Tampil_Tanggal();
        Tampil_Jam();
        kondisiawal();
        dataFromDataBaseToComboBox();
        kosong();
        txt_namasupp.setVisible(false);
        txt_kodeuserpembelian.setVisible(false);
        txt_kodesupp.setVisible(false);
        jLabel10.setVisible(false);
    }
    
    public void kondisiawal(){
    txt_bayar.setEnabled(false);
    txt_harga.setEnabled(false);
    txt_jumlah.setEnabled(false);
    txt_kembalian.setEnabled(false);
    txt_namabarang.setEnabled(false);
    txt_total.setEnabled(false);
    btn_tambah.setEnabled(false);
    btn_hapus.setEnabled(false);
    btn_simpan.setEnabled(false);
    btn_cancel.setEnabled(false);
    }
    
    public void aktif(){
    txt_bayar.setEnabled(true);
    txt_harga.setEnabled(true);
    txt_jumlah.setEnabled(true);
    txt_kembalian.setEnabled(true);
    txt_namabarang.setEnabled(true);
    txt_total.setEnabled(true);
    btn_tambah.setEnabled(true);
    btn_hapus.setEnabled(true);
    btn_simpan.setEnabled(true);
    btn_cancel.setEnabled(true);
    
    }
    
    Connection con;
    PreparedStatement pst;

    
    public void Connect()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            try {
                con = DriverManager.getConnection("jdbc:mysql://217.21.72.102:3306/u1694897_kel20", "u1694897_smt1", "@polije.ac.id");
            } catch (SQLException ex) {
                Logger.getLogger(Pembelian.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Pembelian.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void dataFromDataBaseToComboBox(){
        Connect();
        try {
        String sql = "select supplier.kode_supplier, supplier.nama_supplier from supplier order by kode_supplier ASC";
        java.sql.Connection conn=(Connection)Connect.configDB();
        java.sql.Statement stm=conn.createStatement();
        java.sql.ResultSet res=stm.executeQuery(sql);
            
            while (res.next()) {
                //jComboBox1.addItem("kode_supplier" & "nama_supplier");
            Object[] ob = new Object[3];
            ob[0] = res.getString(1);
            ob[1] = res.getString(2);
            txt_kodesupp.addItem((String) ob[0]);
            }
            
            res.last();
            int jumlahdata = res.getRow();
            res.first();
            
        } catch (SQLException e) {
        }
    }
 public void tampil_text(){
        Connect();
        try {
        String sql = "select supplier.kode_supplier, supplier.nama_supplier from supplier where kode_supplier='"+txt_kodesupp.getSelectedItem()+"'";
        //"select Nama, Jenis_kelamin, Jurusan from nama_tabel_anda where NIM='"+jComboBoxNIM.getSelectedItem()+"'"
        java.sql.Connection conn=(Connection)Connect.configDB();
        java.sql.Statement stm=conn.createStatement();
        java.sql.ResultSet res=stm.executeQuery(sql);
        
        while(res.next()){
            Object[] ob = new Object[3];
            ob[0]=  res.getString(2);
            
            txt_namasupp.setText((String) ob[0]);

        }
        res.close(); stm.close();
         
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }              
    }

    public void Tampil_Jam(){
        ActionListener taskPerformer = new ActionListener() {
 
        @Override
            public void actionPerformed(ActionEvent evt) {
            String nol_jam = "", nol_menit = "",nol_detik = "";
 
            java.util.Date dateTime = new java.util.Date();
            int nilai_jam = dateTime.getHours();
            int nilai_menit = dateTime.getMinutes();
            int nilai_detik = dateTime.getSeconds();
 
            if(nilai_jam <= 9) nol_jam= "0";
            if(nilai_menit <= 9) nol_menit= "0";
            if(nilai_detik <= 9) nol_detik= "0";
 
            String jam = nol_jam + Integer.toString(nilai_jam);
            String menit = nol_menit + Integer.toString(nilai_menit);
            String detik = nol_detik + Integer.toString(nilai_detik);
 
            txt_jam.setText(jam+":"+menit+":"+detik+"");
            }
        };
    new Timer(1000, taskPerformer).start();
    }   
 
public void Tampil_Tanggal() {
    java.util.Date tglsekarang = new java.util.Date();
    SimpleDateFormat smpdtfmt = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    String tanggal = smpdtfmt.format(tglsekarang);
    txt_tanggal.setText(tanggal);
}
   
    private void kosong () {
    kodepembelian.enable();
    txt_namabarang.setText(null);
    txt_jumlah.setText(null);
    txt_harga.setText(null);
    txt_total.setText(null);
    }
    
    public void invoiceid(){
        try{
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select MAX(kode_pembelian) from pembelian");
            rs.next();
            rs.getString("MAX(kode_pembelian)");
            if (rs.getString("MAX(kode_pembelian)")== null) 
            {
               kodepembelian.setText("PB001");
            } else {
               long id = Long.parseLong(rs.getString("MAX(kode_pembelian)").substring(2,rs.getString("MAX(kode_pembelian)").length()));
               id++;
               kodepembelian.setText("PB" + String.format("%03d", id));
            }

           }catch(Exception e){
           
           }
     }
    
    public void munculdata(){            
        DefaultTableModel model = (DefaultTableModel) tablepembelian.getModel();
        try { 
            int qty = Integer.parseInt(txt_jumlah.getText());
                String sql = "select * from barang where nama_barang='"+txt_namabarang.getText()+"'";
                java.sql.Connection conn=(Connection)Connect.configDB();
                java.sql.Statement stm=conn.createStatement();
                java.sql.ResultSet res=stm.executeQuery(sql);
                while (res.next()) {
                    int harga_satuan = Integer.parseInt(res.getString(5));
                    int sub_total = qty * harga_satuan;
                    model.addRow(new Object[] {res.getString(1),
                            res.getString(2), qty,res.getString(4),sub_total});
            }
        } catch (Exception e) {    
        }
    
    }
    
    public void totalsemua(){
        int sum =0;
        for (int i=0; i<tablepembelian.getRowCount(); i++) {
            sum = sum + Integer.parseInt(tablepembelian.getValueAt(i, 4).toString());}
        txt_total.setText(Integer.toString(sum));
    }
    
    public void kembalian(){
        try{
        int sum =0;
        for (int i=0; i<tablepembelian.getRowCount(); i++) {
            sum = sum + Integer.parseInt(tablepembelian.getValueAt(i, 4).toString());}
        txt_total.setText(Integer.toString(sum));
        int bayar = Integer.parseInt(txt_bayar.getText());
        int kembalian = bayar - sum;
        txt_kembalian.setText(Integer.toString(kembalian));  
        }catch(Exception e){
            
        }
        
    }
    
    public void simpandata(){
        try {
            String sql = "INSERT INTO `pembelian`(`kode_pembelian`, `tanggal`, kode_supplier, kode_user) VALUES (?,?,?,?)";
            String sqll = "INSERT INTO `pembelian_detil`(`kode_pembelian`, `kode_barang`, `jumlah`, `harga_beli`, `total`) VALUES (?,?,?,?,?)";
            java.sql.Connection conn=(Connection)Connect.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            java.sql.PreparedStatement pstl=conn.prepareStatement(sqll);
            pst.setString(1, kodepembelian.getText());
            pst.setString(2, txt_tanggal.getText());
            pst.setObject(3, txt_kodesupp.getSelectedItem());
            pst.setString(4, txt_kodeuserpembelian.getText());
            DefaultTableModel model = (DefaultTableModel) tablepembelian.getModel();
            pst.execute();
            for(int i=0; i<model.getRowCount(); i++) {
                pstl.setString(1,kodepembelian.getText());
                pstl.setString(2,model.getValueAt(i, 0).toString());
                pstl.setInt(3,Integer.parseInt(model.getValueAt(i, 2).toString()));
                pstl.setInt(4,Integer.parseInt(model.getValueAt(i, 3).toString()));
                pstl.setInt(5,Integer.parseInt(model.getValueAt(i, 4).toString()));
            pstl.execute();
            }
            JOptionPane.showMessageDialog(this, "Berhasil");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        } 
    }
    
    private void pengurangan_stok() {
        try {
                String sql = "select * from barang where nama_barang ='"+txt_namabarang.getText()+"'";
                java.sql.Connection conn=(Connection)Connect.configDB();
                java.sql.Statement stm=conn.createStatement();
                java.sql.ResultSet res=stm.executeQuery(sql);  
                while (res.next()) {
                int oldqty = Integer.parseInt(res.getString(3));
                int newqty = oldqty + Integer.parseInt(txt_jumlah.getText());                  
                String sqll = "UPDATE `barang`" + "SET `stok`='"+newqty+"' WHERE `nama_barang` = '"+txt_namabarang.getText()+"'";
                java.sql.PreparedStatement pstl=conn.prepareStatement(sqll);
                pstl.execute();
                }
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txt_jam = new javax.swing.JTextField();
        btn_simpan = new javax.swing.JButton();
        txt_kembalian = new javax.swing.JTextField();
        txt_kodesupp = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        kodepembelian = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        btn_kembali = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablepembelian = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        txt_total = new javax.swing.JTextField();
        txt_bayar = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txt_namabarang = new javax.swing.JTextField();
        txt_harga = new javax.swing.JTextField();
        txt_jumlah = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        btn_tambah = new javax.swing.JButton();
        btn_hapus = new javax.swing.JButton();
        txt_tanggal = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        btn_add = new javax.swing.JButton();
        btn_cancel = new javax.swing.JButton();
        txt_namasupp = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(300, 0));
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        setResizable(false);
        setSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(null);

        txt_jam.setEditable(false);
        txt_jam.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_jam.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_jam);
        txt_jam.setBounds(750, 230, 90, 40);

        btn_simpan.setBackground(new java.awt.Color(108, 52, 68));
        btn_simpan.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_simpan.setForeground(new java.awt.Color(255, 255, 255));
        btn_simpan.setText("Simpan");
        btn_simpan.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_simpan.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_simpan.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_simpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_simpanActionPerformed(evt);
            }
        });
        getContentPane().add(btn_simpan);
        btn_simpan.setBounds(1380, 860, 130, 40);

        txt_kodeuserpembelian.setEditable(false);
        txt_kodeuserpembelian.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        txt_kodeuserpembelian.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_kodeuserpembelian);
        txt_kodeuserpembelian.setBounds(1520, 170, 80, 40);

        txt_kembalian.setEditable(false);
        txt_kembalian.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_kembalian.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_kembalian);
        txt_kembalian.setBounds(1350, 810, 160, 40);

        txt_kodesupp.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_kodesupp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_kodesuppActionPerformed(evt);
            }
        });
        getContentPane().add(txt_kodesupp);
        txt_kodesupp.setBounds(1390, 230, 120, 40);

        jLabel10.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(108, 52, 68));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel10.setText(" Supplier");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(1260, 230, 120, 30);

        jLabel4.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(108, 52, 68));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel4.setText("User");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(1240, 170, 140, 40);

        jLabel5.setFont(new java.awt.Font("Montserrat", 1, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(108, 52, 68));
        jLabel5.setText("TOTAL");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(430, 760, 130, 90);

        jLabel6.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(108, 52, 68));
        jLabel6.setText("Tanggal");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(430, 230, 180, 40);

        jLabel7.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(108, 52, 68));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Bayar");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(1240, 760, 60, 40);

        kodepembelian.setEditable(false);
        kodepembelian.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        kodepembelian.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(kodepembelian);
        kodepembelian.setBounds(610, 180, 230, 40);

        jLabel8.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(108, 52, 68));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Kembalian");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(1240, 810, 100, 40);

        btn_kembali.setBackground(new java.awt.Color(108, 52, 68));
        btn_kembali.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_kembali.setForeground(new java.awt.Color(255, 255, 255));
        btn_kembali.setText("Kembali");
        btn_kembali.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_kembali.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_kembali.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_kembali.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_kembaliActionPerformed(evt);
            }
        });
        getContentPane().add(btn_kembali);
        btn_kembali.setBounds(1750, 40, 130, 40);

        tablepembelian.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        tablepembelian.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Kode Barang", "Nama Barang", "Jumlah", "Harga", "Subtotal"
            }
        ));
        tablepembelian.setToolTipText("");
        tablepembelian.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablepembelianMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablepembelian);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(430, 400, 1080, 350);

        jLabel9.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(108, 52, 68));
        jLabel9.setText("Kode Pembelian");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(430, 180, 180, 40);

        txt_total.setEditable(false);
        txt_total.setFont(new java.awt.Font("Calibri", 0, 48)); // NOI18N
        txt_total.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_total);
        txt_total.setBounds(560, 760, 660, 90);

        txt_bayar.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_bayar.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txt_bayar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_bayarKeyReleased(evt);
            }
        });
        getContentPane().add(txt_bayar);
        txt_bayar.setBounds(1350, 760, 160, 40);

        jPanel1.setBackground(java.awt.Color.orange);
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(245, 202, 33), java.awt.Color.white));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        jPanel1.setLayout(null);

        jLabel3.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(108, 52, 68));
        jLabel3.setText("Qty");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(570, 10, 40, 30);

        txt_namabarang.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_namabarang.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txt_namabarang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_namabarangKeyReleased(evt);
            }
        });
        jPanel1.add(txt_namabarang);
        txt_namabarang.setBounds(80, 40, 200, 40);

        txt_harga.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_harga.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(txt_harga);
        txt_harga.setBounds(340, 40, 140, 40);

        txt_jumlah.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_jumlah.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(txt_jumlah);
        txt_jumlah.setBounds(540, 40, 90, 40);

        jLabel12.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(108, 52, 68));
        jLabel12.setText("Nama Barang");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(120, 10, 130, 30);

        jLabel13.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(108, 52, 68));
        jLabel13.setText("Harga");
        jPanel1.add(jLabel13);
        jLabel13.setBounds(380, 10, 60, 30);

        btn_tambah.setBackground(new java.awt.Color(108, 52, 68));
        btn_tambah.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_tambah.setForeground(new java.awt.Color(255, 255, 255));
        btn_tambah.setText("Tambah");
        btn_tambah.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_tambah.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_tambah.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahActionPerformed(evt);
            }
        });
        jPanel1.add(btn_tambah);
        btn_tambah.setBounds(710, 40, 130, 40);

        btn_hapus.setBackground(new java.awt.Color(108, 52, 68));
        btn_hapus.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_hapus.setForeground(new java.awt.Color(255, 255, 255));
        btn_hapus.setText("Hapus");
        btn_hapus.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_hapus.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_hapus.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_hapus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_hapusMouseClicked(evt);
            }
        });
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });
        jPanel1.add(btn_hapus);
        btn_hapus.setBounds(860, 40, 130, 40);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(430, 280, 1080, 110);

        txt_tanggal.setEditable(false);
        txt_tanggal.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_tanggal.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_tanggal);
        txt_tanggal.setBounds(610, 230, 130, 40);

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/logo 380.png"))); // NOI18N
        jLabel11.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel11.setInheritsPopupMenu(false);
        jLabel11.setMaximumSize(new java.awt.Dimension(620, 140));
        jLabel11.setMinimumSize(new java.awt.Dimension(620, 140));
        jLabel11.setPreferredSize(new java.awt.Dimension(620, 140));
        getContentPane().add(jLabel11);
        jLabel11.setBounds(0, 0, 380, 90);

        btn_add.setBackground(new java.awt.Color(108, 52, 68));
        btn_add.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_add.setForeground(new java.awt.Color(255, 255, 255));
        btn_add.setText("Add");
        btn_add.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_add.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_add.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addActionPerformed(evt);
            }
        });
        getContentPane().add(btn_add);
        btn_add.setBounds(930, 230, 130, 40);

        btn_cancel.setBackground(new java.awt.Color(108, 52, 68));
        btn_cancel.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_cancel.setForeground(new java.awt.Color(255, 255, 255));
        btn_cancel.setText("Cancel");
        btn_cancel.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_cancel.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_cancel.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cancel);
        btn_cancel.setBounds(1070, 230, 130, 40);

        txt_namasupp.setFont(new java.awt.Font("Tahoma", 0, 20)); // NOI18N
        getContentPane().add(txt_namasupp);
        txt_namasupp.setBounds(1520, 230, 80, 40);

        txt_namauserpembelian.setEditable(false);
        txt_namauserpembelian.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_namauserpembelian.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_namauserpembelian);
        txt_namauserpembelian.setBounds(1390, 170, 120, 40);

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 48)); // NOI18N
        jLabel1.setText("FORM PEMBELIAN");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(770, 80, 380, 50);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Background 1920x1080.png"))); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel2.setMaximumSize(new java.awt.Dimension(1280, 720));
        jLabel2.setMinimumSize(new java.awt.Dimension(1280, 720));
        jLabel2.setPreferredSize(new java.awt.Dimension(1280, 720));
        jLabel2.setRequestFocusEnabled(false);
        jLabel2.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 1920, 1080);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_simpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_simpanActionPerformed
        simpandata();
        invoiceid();
        kosong();
        kondisiawal();
        btn_add.setEnabled(true);
        DefaultTableModel model = (DefaultTableModel)tablepembelian.getModel();
        model.setRowCount(0);
        txt_bayar.setText(null);
        txt_kembalian.setText(null);
    }//GEN-LAST:event_btn_simpanActionPerformed

    private void btn_kembaliActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_kembaliActionPerformed
        this.setVisible(false);
        new MenuTransaksi().setVisible(true);
    }//GEN-LAST:event_btn_kembaliActionPerformed

    private void btn_tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahActionPerformed
        munculdata();
        totalsemua();
        pengurangan_stok();
        txt_namabarang.setText(null);
        txt_jumlah.setText(null);
        txt_harga.setText(null);
        txt_namabarang.requestFocus();
    }//GEN-LAST:event_btn_tambahActionPerformed

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_hapusActionPerformed

    private void tablepembelianMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablepembelianMouseClicked
        int baris = tablepembelian.rowAtPoint(evt.getPoint());
        String kode_pembelian = kodepembelian.getText();
        kodepembelian.setText(kode_pembelian);
        kodepembelian.disable();
        if (tablepembelian.getValueAt(baris, 1)==null) {
            txt_namabarang.setText("");
        } else {
            txt_namabarang.setText(tablepembelian.getValueAt(baris, 1).toString());
        }
        if (tablepembelian.getValueAt(baris, 2)==null) {
            txt_jumlah.setText("");
        } else {
            txt_jumlah.setText(tablepembelian.getValueAt(baris, 2).toString());
        }
        if (tablepembelian.getValueAt(baris, 3)==null) {
            txt_harga.setText("");
        } else {
            txt_harga.setText(tablepembelian.getValueAt(baris, 3).toString());
        }
        
    }//GEN-LAST:event_tablepembelianMouseClicked

    private void btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addActionPerformed
        // TODO add your handling code here:
        aktif();
        invoiceid();
        btn_add.setEnabled(false);
        txt_namabarang.requestFocus();
    }//GEN-LAST:event_btn_addActionPerformed

    private void btn_cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelActionPerformed
        // TODO add your handling code here:
        kosong();
        kondisiawal();
        btn_add.setEnabled(true);
        //nonaktif();
        //btn_tambah.setEnabled(true);
    }//GEN-LAST:event_btn_cancelActionPerformed

    private void txt_namabarangKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_namabarangKeyReleased
        try {

                String sql = "select * from barang where nama_barang='"+txt_namabarang.getText()+"'";
                java.sql.Connection conn=(Connection)Connect.configDB();
                java.sql.Statement stm=conn.createStatement();
                java.sql.ResultSet res=stm.executeQuery(sql);
                while(res.next()) {
                txt_harga.setText(res.getString("harga_beli"));
                }            
        } catch (Exception e) {
        }
        if (txt_namabarang.getText().equals("")) {
            txt_harga.setText(null);
        }
    }//GEN-LAST:event_txt_namabarangKeyReleased

    private void txt_bayarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_bayarKeyReleased
       kembalian();
    }//GEN-LAST:event_txt_bayarKeyReleased

    private void txt_kodesuppActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_kodesuppActionPerformed
       tampil_text();
    }//GEN-LAST:event_txt_kodesuppActionPerformed

    private void btn_hapusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_hapusMouseClicked
        DefaultTableModel model = (DefaultTableModel) tablepembelian.getModel();
        try {
            int rs[] = tablepembelian.getSelectedRows();
            for (int i=0; i<rs.length; i++) {
                String sql = "select * from barang where nama_barang ='"+model.getValueAt(i, 1).toString()+"'";
                java.sql.Connection conn=(Connection)Connect.configDB();
                java.sql.Statement stm=conn.createStatement();
                java.sql.ResultSet res=stm.executeQuery(sql);  
                while (res.next()) {
                int oldqty = Integer.parseInt(res.getString(3));
                int newqty = oldqty - Integer.parseInt(model.getValueAt(i, 2).toString());                  
                String sqll = "UPDATE `barang`" + "SET `stok`='"+newqty+"' WHERE `nama_barang` = '"+model.getValueAt(i, 1).toString()+"'";
                java.sql.PreparedStatement pstl=conn.prepareStatement(sqll);
                pstl.execute();                        
                    }
                }
        } catch(Exception e) {

        }
        int[] rows = tablepembelian.getSelectedRows();
        for(int i=0;i<rows.length;i++){
            model.removeRow(rows[i]-i);
        }
        
        if  (tablepembelian.getRowCount()==0) {
            txt_total.setText("0");
            txt_bayar.setText(null);
            txt_kembalian.setText(null);
        }
        totalsemua();
    }//GEN-LAST:event_btn_hapusMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Pembelian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Pembelian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Pembelian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Pembelian.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Pembelian().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_add;
    private javax.swing.JButton btn_cancel;
    private javax.swing.JButton btn_hapus;
    private javax.swing.JButton btn_kembali;
    private javax.swing.JButton btn_simpan;
    private javax.swing.JButton btn_tambah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private static javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField kodepembelian;
    private javax.swing.JTable tablepembelian;
    private javax.swing.JTextField txt_bayar;
    private javax.swing.JTextField txt_harga;
    private javax.swing.JTextField txt_jam;
    private javax.swing.JTextField txt_jumlah;
    private javax.swing.JTextField txt_kembalian;
    private javax.swing.JComboBox<String> txt_kodesupp;
    public static final javax.swing.JTextField txt_kodeuserpembelian = new javax.swing.JTextField();
    private javax.swing.JTextField txt_namabarang;
    private javax.swing.JTextField txt_namasupp;
    public static final javax.swing.JTextField txt_namauserpembelian = new javax.swing.JTextField();
    private javax.swing.JTextField txt_tanggal;
    private javax.swing.JTextField txt_total;
    // End of variables declaration//GEN-END:variables
}
