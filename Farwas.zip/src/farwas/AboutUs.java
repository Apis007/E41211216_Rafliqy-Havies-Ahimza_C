package farwas;

public class AboutUs extends javax.swing.JFrame {

    public AboutUs() {
        initComponents();

    }

   

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        aa = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btn_logout = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(300, 0));
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        setResizable(false);
        setSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(null);

        aa.setBackground(new java.awt.Color(0, 0, 0));
        aa.setLayout(null);
        getContentPane().add(aa);
        aa.setBounds(345, 0, 5, 1080);

        jPanel1.setBackground(new java.awt.Color(255, 103, 0));
        jPanel1.setLayout(null);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/developer.png"))); // NOI18N
        jPanel1.add(jLabel4);
        jLabel4.setBounds(90, 190, 200, 210);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/phone.png"))); // NOI18N
        jPanel1.add(jLabel6);
        jLabel6.setBounds(30, 470, 40, 40);

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/gmail.png"))); // NOI18N
        jPanel1.add(jLabel7);
        jLabel7.setBounds(30, 420, 40, 40);

        jLabel8.setFont(new java.awt.Font("Calibri", 1, 19)); // NOI18N
        jLabel8.setText("+62 858-9489-3282");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(80, 480, 240, 20);

        jLabel9.setFont(new java.awt.Font("Calibri", 1, 20)); // NOI18N
        jLabel9.setText("farwasstationary@gmail.com");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(80, 430, 250, 30);
        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, -30, 10, 10);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 180, 350, 900);

        jPanel2.setBackground(new java.awt.Color(254, 147, 0));
        jPanel2.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Calibri", 1, 48)); // NOI18N
        jLabel2.setText("DEVELOPER");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(50, 70, 240, 50);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Logout.png"))); // NOI18N
        jPanel2.add(jLabel5);
        jLabel5.setBounds(1710, 20, 100, 100);

        btn_logout.setBackground(new java.awt.Color(255, 117, 0));
        btn_logout.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        btn_logout.setForeground(new java.awt.Color(255, 255, 255));
        btn_logout.setText("KEMBALI");
        btn_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logoutActionPerformed(evt);
            }
        });
        jPanel2.add(btn_logout);
        btn_logout.setBounds(1690, 110, 150, 50);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/logo 470.png"))); // NOI18N
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel3.setInheritsPopupMenu(false);
        jLabel3.setMaximumSize(new java.awt.Dimension(620, 140));
        jLabel3.setMinimumSize(new java.awt.Dimension(620, 140));
        jLabel3.setPreferredSize(new java.awt.Dimension(620, 140));
        jPanel2.add(jLabel3);
        jLabel3.setBounds(760, 20, 560, 150);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 0, 1920, 180);

        jLabel10.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel10.setText("Fans. Ach Farrosil");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(1340, 860, 190, 30);

        jLabel11.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel11.setText("Muhammad Wahyu");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(780, 540, 210, 30);

        jLabel12.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel12.setText("Rafliqy Havies Ahimza");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(1050, 540, 230, 30);

        jLabel14.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel14.setText("Rio Javier Reyhan");
        getContentPane().add(jLabel14);
        jLabel14.setBounds(1340, 540, 180, 30);

        jLabel15.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel15.setText("Akbar Firmansyah");
        getContentPane().add(jLabel15);
        jLabel15.setBounds(790, 860, 190, 30);

        jLabel16.setFont(new java.awt.Font("Calibri", 1, 24)); // NOI18N
        jLabel16.setText("Syahra Fajarila");
        getContentPane().add(jLabel16);
        jLabel16.setBounds(1080, 860, 160, 30);

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Rio.png"))); // NOI18N
        getContentPane().add(jLabel13);
        jLabel13.setBounds(1330, 330, 200, 200);

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Farros.png"))); // NOI18N
        getContentPane().add(jLabel17);
        jLabel17.setBounds(1330, 650, 200, 200);

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Wahyu.png"))); // NOI18N
        getContentPane().add(jLabel18);
        jLabel18.setBounds(780, 330, 200, 200);

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Akbar.png"))); // NOI18N
        getContentPane().add(jLabel20);
        jLabel20.setBounds(780, 650, 200, 200);

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/FOTO.png"))); // NOI18N
        getContentPane().add(jLabel21);
        jLabel21.setBounds(1060, 650, 200, 200);

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Havies.png"))); // NOI18N
        getContentPane().add(jLabel22);
        jLabel22.setBounds(1060, 330, 200, 200);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Background 1920x1080.png"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(350, 180, 1920, 1050);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logoutActionPerformed
        this.setVisible(false);
        new MenuUtama().setVisible(true);
    }//GEN-LAST:event_btn_logoutActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(AboutUs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(AboutUs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(AboutUs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(AboutUs.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
       java.awt.EventQueue.invokeLater(new Runnable() {
           public void run() {
               new AboutUs().setVisible(true);
           }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel aa;
    private javax.swing.JButton btn_logout;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    // End of variables declaration//GEN-END:variables
}
