package farwas;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
public class Connect {
    private static Connection mysqlconfig;
    static Connection configDB()throws SQLException {
         try {
            String url="jdbc:mysql://217.21.72.102:3306/u1694897_kel20";
            String user="u1694897_smt1";
            String pass="@polije.ac.id";
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
            mysqlconfig=DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            System.err.println("Koneksi gagal "+e.getMessage());
        }
        return mysqlconfig;
    }
    static Connection getConnect() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}