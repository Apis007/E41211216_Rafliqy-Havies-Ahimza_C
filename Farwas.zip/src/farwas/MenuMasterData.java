package farwas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Locale;
import javax.swing.JOptionPane;
import javax.swing.Timer;
public class MenuMasterData extends javax.swing.JFrame {

    public MenuMasterData() {
        initComponents();
        Tampil_Tanggal();
        Tampil_Jam();
    }

    public void Tampil_Jam(){
        ActionListener taskPerformer = new ActionListener() {
 
        @Override
            public void actionPerformed(ActionEvent evt) {
            String nol_jam = "", nol_menit = "",nol_detik = "";
 
            java.util.Date dateTime = new java.util.Date();
            int nilai_jam = dateTime.getHours();
            int nilai_menit = dateTime.getMinutes();
            int nilai_detik = dateTime.getSeconds();
 
            if(nilai_jam <= 9) nol_jam= "0";
            if(nilai_menit <= 9) nol_menit= "0";
            if(nilai_detik <= 9) nol_detik= "0";
 
            String jam = nol_jam + Integer.toString(nilai_jam);
            String menit = nol_menit + Integer.toString(nilai_menit);
            String detik = nol_detik + Integer.toString(nilai_detik);
 
            txt_jam.setText(jam+":"+menit+":"+detik+"");
            }
        };
    new Timer(1000, taskPerformer).start();
    }   
 
public void Tampil_Tanggal() {
    java.util.Date tglsekarang = new java.util.Date();
    SimpleDateFormat smpdtfmt = new SimpleDateFormat("dd MMMMMMMMM yyyy", Locale.getDefault());
    String tanggal = smpdtfmt.format(tglsekarang);
    txt_tanggal.setText(tanggal);
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btn_masterdata = new javax.swing.JButton();
        btn_transaksi = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        btn_datatransaksi = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btn_logout = new javax.swing.JButton();
        btn_databarang = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        btn_datasupplier = new javax.swing.JButton();
        btn_datapengguna = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txt_tanggal = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txt_jam = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(300, 0));
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        setResizable(false);
        setSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(null);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/logo 770.png"))); // NOI18N
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel3.setInheritsPopupMenu(false);
        jLabel3.setMaximumSize(new java.awt.Dimension(620, 140));
        jLabel3.setMinimumSize(new java.awt.Dimension(620, 140));
        jLabel3.setPreferredSize(new java.awt.Dimension(620, 140));
        getContentPane().add(jLabel3);
        jLabel3.setBounds(530, 40, 880, 320);

        jPanel1.setBackground(new java.awt.Color(255, 103, 0));
        jPanel1.setLayout(null);

        btn_masterdata.setBackground(new java.awt.Color(255, 117, 0));
        btn_masterdata.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        btn_masterdata.setForeground(new java.awt.Color(255, 255, 255));
        btn_masterdata.setText("Master Data");
        btn_masterdata.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_masterdataActionPerformed(evt);
            }
        });
        jPanel1.add(btn_masterdata);
        btn_masterdata.setBounds(130, 180, 180, 50);

        btn_transaksi.setBackground(new java.awt.Color(255, 117, 0));
        btn_transaksi.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        btn_transaksi.setForeground(new java.awt.Color(255, 255, 255));
        btn_transaksi.setText("Transaksi");
        btn_transaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_transaksiActionPerformed(evt);
            }
        });
        jPanel1.add(btn_transaksi);
        btn_transaksi.setBounds(130, 420, 180, 50);

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Transaksi.png"))); // NOI18N
        jPanel1.add(jLabel11);
        jLabel11.setBounds(150, 270, 140, 160);

        btn_datatransaksi.setBackground(new java.awt.Color(255, 117, 0));
        btn_datatransaksi.setFont(new java.awt.Font("SansSerif", 1, 24)); // NOI18N
        btn_datatransaksi.setForeground(new java.awt.Color(255, 255, 255));
        btn_datatransaksi.setText("Laporan");
        btn_datatransaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_datatransaksiActionPerformed(evt);
            }
        });
        jPanel1.add(btn_datatransaksi);
        btn_datatransaksi.setBounds(130, 650, 180, 50);

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Master Data.png"))); // NOI18N
        jPanel1.add(jLabel13);
        jLabel13.setBounds(150, 40, 140, 140);

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/data penjualan.png"))); // NOI18N
        jPanel1.add(jLabel12);
        jLabel12.setBounds(150, 510, 130, 140);

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 0, 440, 5);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 270, 440, 810);

        jPanel2.setBackground(new java.awt.Color(255, 135, 0));
        jPanel2.setLayout(null);

        jLabel6.setFont(new java.awt.Font("Calibri", 1, 48)); // NOI18N
        jLabel6.setText("MASTER DATA");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(70, 120, 310, 40);

        getContentPane().add(jPanel2);
        jPanel2.setBounds(0, 0, 440, 270);

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Data Barang.png"))); // NOI18N
        getContentPane().add(jLabel4);
        jLabel4.setBounds(710, 480, 150, 150);

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Logout.png"))); // NOI18N
        getContentPane().add(jLabel5);
        jLabel5.setBounds(1750, 830, 100, 100);

        btn_logout.setBackground(new java.awt.Color(255, 117, 0));
        btn_logout.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        btn_logout.setForeground(new java.awt.Color(255, 255, 255));
        btn_logout.setText("KEMBALI");
        btn_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logoutActionPerformed(evt);
            }
        });
        getContentPane().add(btn_logout);
        btn_logout.setBounds(1730, 920, 150, 50);

        btn_databarang.setBackground(new java.awt.Color(255, 117, 0));
        btn_databarang.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        btn_databarang.setForeground(new java.awt.Color(255, 255, 255));
        btn_databarang.setText("DATA BARANG");
        btn_databarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_databarangActionPerformed(evt);
            }
        });
        getContentPane().add(btn_databarang);
        btn_databarang.setBounds(700, 630, 180, 60);

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/data supplier.png"))); // NOI18N
        getContentPane().add(jLabel14);
        jLabel14.setBounds(1030, 480, 150, 150);

        btn_datasupplier.setBackground(new java.awt.Color(255, 117, 0));
        btn_datasupplier.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        btn_datasupplier.setForeground(new java.awt.Color(255, 255, 255));
        btn_datasupplier.setText("DATA SUPPLIER");
        btn_datasupplier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_datasupplierActionPerformed(evt);
            }
        });
        getContentPane().add(btn_datasupplier);
        btn_datasupplier.setBounds(1020, 630, 180, 60);

        btn_datapengguna.setBackground(new java.awt.Color(255, 117, 0));
        btn_datapengguna.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        btn_datapengguna.setForeground(new java.awt.Color(255, 255, 255));
        btn_datapengguna.setText("DATA USER");
        btn_datapengguna.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_datapenggunaActionPerformed(evt);
            }
        });
        getContentPane().add(btn_datapengguna);
        btn_datapengguna.setBounds(1340, 630, 180, 60);

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/data pengguna.png"))); // NOI18N
        getContentPane().add(jLabel15);
        jLabel15.setBounds(1350, 490, 150, 150);

        jLabel10.setFont(new java.awt.Font("Calibri", 1, 26)); // NOI18N
        jLabel10.setText("Tanggal");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(1550, 50, 100, 30);

        txt_tanggal.setFont(new java.awt.Font("Calibri", 1, 26)); // NOI18N
        getContentPane().add(txt_tanggal);
        txt_tanggal.setBounds(1670, 50, 210, 30);

        jLabel9.setFont(new java.awt.Font("Calibri", 1, 26)); // NOI18N
        jLabel9.setText("Jam");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(1550, 90, 90, 30);

        txt_jam.setFont(new java.awt.Font("Calibri", 1, 26)); // NOI18N
        getContentPane().add(txt_jam);
        txt_jam.setBounds(1670, 90, 210, 30);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Background 1920x1080.png"))); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel2.setName(""); // NOI18N
        jLabel2.setRequestFocusEnabled(false);
        jLabel2.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel2);
        jLabel2.setBounds(440, 0, 1810, 1080);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_masterdataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_masterdataActionPerformed
        this.setVisible(false);
        new MenuMasterData().setVisible(true);
    }//GEN-LAST:event_btn_masterdataActionPerformed

    private void btn_transaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_transaksiActionPerformed
        this.setVisible(false);
        new MenuTransaksi().setVisible(true);
    }//GEN-LAST:event_btn_transaksiActionPerformed

    private void btn_datatransaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_datatransaksiActionPerformed
        this.setVisible(false);
        new MenuDataTransaksi().setVisible(true);
    }//GEN-LAST:event_btn_datatransaksiActionPerformed

    private void btn_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logoutActionPerformed
        this.setVisible(false);
        new MenuUtama().setVisible(true);
    }//GEN-LAST:event_btn_logoutActionPerformed

    private void btn_databarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_databarangActionPerformed
        this.setVisible(false);
        new DataBarang().setVisible(true);
    }//GEN-LAST:event_btn_databarangActionPerformed

    private void btn_datasupplierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_datasupplierActionPerformed
        this.setVisible(false);
        new DataSupplier().setVisible(true);
    }//GEN-LAST:event_btn_datasupplierActionPerformed

    private void btn_datapenggunaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_datapenggunaActionPerformed
        this.setVisible(false);
        new DataUser().setVisible(true);
    }//GEN-LAST:event_btn_datapenggunaActionPerformed

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MenuMasterData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MenuMasterData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MenuMasterData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MenuMasterData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
       java.awt.EventQueue.invokeLater(new Runnable() {
           public void run() {
               new MenuMasterData().setVisible(true);
           }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_databarang;
    private javax.swing.JButton btn_datapengguna;
    private javax.swing.JButton btn_datasupplier;
    private javax.swing.JButton btn_datatransaksi;
    private javax.swing.JButton btn_logout;
    private javax.swing.JButton btn_masterdata;
    private javax.swing.JButton btn_transaksi;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private static javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel txt_jam;
    private javax.swing.JLabel txt_tanggal;
    // End of variables declaration//GEN-END:variables
}
