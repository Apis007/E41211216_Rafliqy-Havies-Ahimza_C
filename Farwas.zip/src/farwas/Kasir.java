/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package farwas;

import static farwas.ENotaKasir.txt_area;
import static farwas.login.txt_password;
import static farwas.login.txt_username;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.Timer;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Apis
 */
public class Kasir extends javax.swing.JFrame {

    /**
     * Creates new form login
     */
    public Kasir() {
        txt_userkasir.setVisible(false);
        initComponents();
        Connect();
        Tampil_Tanggal();
        Tampil_Jam();
        kondisiawal();
        kosong();
        
    }
    public void kondisiawal(){
    txt_bayarr.setEnabled(false);
    txt_harga.setEnabled(false);
    txt_jumlah.setEnabled(false);
    txt_kembalian.setEnabled(false);
    txt_namabarang.setEnabled(false);
    txt_total.setEnabled(false);
    btn_tambah.setEnabled(false);
    btn_hapus.setEnabled(false);
    btn_cetak.setEnabled(false);
    btn_cancel.setEnabled(false);
    }
    
    public void aktif(){
    txt_bayarr.setEnabled(true);
    txt_harga.setEnabled(true);
    txt_jumlah.setEnabled(true);
    txt_kembalian.setEnabled(true);
    txt_namabarang.setEnabled(true);
    txt_total.setEnabled(true);
    btn_tambah.setEnabled(true);
    btn_hapus.setEnabled(true);
    btn_cetak.setEnabled(true);
    btn_cancel.setEnabled(true);
    
    }
    
    Connection con;
    PreparedStatement pst;

    
    public void Connect()
    {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            try {
                con = DriverManager.getConnection("jdbc:mysql://217.21.72.102:3306/u1694897_kel20", "u1694897_smt1", "@polije.ac.id");
            } catch (SQLException ex) {
                Logger.getLogger(Kasir.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Kasir.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void Tampil_Jam(){
        ActionListener taskPerformer = new ActionListener() {
 
        @Override
            public void actionPerformed(ActionEvent evt) {
            String nol_jam = "", nol_menit = "",nol_detik = "";
 
            java.util.Date dateTime = new java.util.Date();
            int nilai_jam = dateTime.getHours();
            int nilai_menit = dateTime.getMinutes();
            int nilai_detik = dateTime.getSeconds();
 
            if(nilai_jam <= 9) nol_jam= "0";
            if(nilai_menit <= 9) nol_menit= "0";
            if(nilai_detik <= 9) nol_detik= "0";
 
            String jam = nol_jam + Integer.toString(nilai_jam);
            String menit = nol_menit + Integer.toString(nilai_menit);
            String detik = nol_detik + Integer.toString(nilai_detik);
 
            txt_jam.setText(jam+":"+menit+":"+detik+"");
            }
        };
    new Timer(1000, taskPerformer).start();
    }   
 
public void Tampil_Tanggal() {
    java.util.Date tglsekarang = new java.util.Date();
    SimpleDateFormat smpdtfmt = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    String tanggal = smpdtfmt.format(tglsekarang);
    txt_tanggal.setText(tanggal);
}
    
    
    private void kosong () {
    txt_kodepenjualan.enable();
    txt_namabarang.setText(null);
    txt_jumlah.setText(null);
    txt_harga.setText(null);
    txt_total.setText(null);
    txt_bayarr.setText(null);
    txt_kembalian.setText(null);
    }
   
    public void invoiceid(){
        try{
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("select MAX(kode_penjualan) from penjualan");
            rs.next();
            rs.getString("MAX(kode_penjualan)");
            if (rs.getString("MAX(kode_penjualan)")== null) 
            {
               txt_kodepenjualan.setText("PJ001");
            } else {
               long id = Long.parseLong(rs.getString("MAX(kode_penjualan)").substring(2,rs.getString("MAX(kode_penjualan)").length()));
               id++;
               txt_kodepenjualan.setText("PJ" + String.format("%03d", id));
            }

           }catch(Exception e){
           
           }
     }
    
    public void munculdata(){            
        DefaultTableModel model = (DefaultTableModel) tablekasir.getModel();
        try { 
            int qty = Integer.parseInt(txt_jumlah.getText());
                String sql = "select * from barang where nama_barang='"+txt_namabarang.getText()+"'";
                java.sql.Connection conn=(Connection)Connect.configDB();
                java.sql.Statement stm=conn.createStatement();
                java.sql.ResultSet res=stm.executeQuery(sql);
                while (res.next()) {
                    int harga_satuan = Integer.parseInt(res.getString(4));
                    int sub_total = qty * harga_satuan;
                    model.addRow(new Object[] {res.getString(1),
                            res.getString(2), qty,res.getString(4),sub_total});
            }
        } catch (Exception e) {    
        }
    
    }
    
    
    public void totalsemua(){
        int sum =0;
        for (int i=0; i<tablekasir.getRowCount(); i++) {
            sum = sum + Integer.parseInt(tablekasir.getValueAt(i, 4).toString());}
        txt_total.setText(Integer.toString(sum));
    }
    
    public void kembalian(){
        try{
        int sum =0;
        for (int i=0; i<tablekasir.getRowCount(); i++) {
            sum = sum + Integer.parseInt(tablekasir.getValueAt(i, 4).toString());}
        txt_total.setText(Integer.toString(sum));
        int bayar = Integer.parseInt(txt_bayarr.getText());
        int kembalian = bayar - sum;
        txt_kembalian.setText(Integer.toString(kembalian));  
        }catch(Exception e){
            
        }
        
    }
    
    public void simpandata(){
        try {
            String sql = "INSERT INTO `penjualan`(`kode_penjualan`, `tanggal`, kode_user) VALUES (?,?,?)";
            String sqll = "INSERT INTO `penjualan_detil`(`kode_penjualan`, `kode_barang`, `jumlah`, `harga_jual`, `total`) VALUES (?,?,?,?,?)";
            java.sql.Connection conn=(Connection)Connect.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            java.sql.PreparedStatement pstl=conn.prepareStatement(sqll);
            pst.setString(1, txt_kodepenjualan.getText());
            pst.setString(2, txt_tanggal.getText());
            pst.setString(3, txt_userkasir.getText());
            DefaultTableModel model = (DefaultTableModel) tablekasir.getModel();
            pst.execute();
            for(int i=0; i<model.getRowCount(); i++) {
                pstl.setString(1,txt_kodepenjualan.getText());
                pstl.setString(2,model.getValueAt(i, 0).toString());
                pstl.setInt(3,Integer.parseInt(model.getValueAt(i, 2).toString()));
                pstl.setInt(4,Integer.parseInt(model.getValueAt(i, 3).toString()));
                pstl.setInt(5,Integer.parseInt(model.getValueAt(i, 4).toString()));
            pstl.execute();
            }
            JOptionPane.showMessageDialog(this, "Berhasil");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        } 
    }
    
    private void pengurangan_stok() {
        try {
                String sql = "select * from barang where nama_barang ='"+txt_namabarang.getText()+"'";
                java.sql.Connection conn=(Connection)Connect.configDB();
                java.sql.Statement stm=conn.createStatement();
                java.sql.ResultSet res=stm.executeQuery(sql);  
                while (res.next()) {
                int oldqty = Integer.parseInt(res.getString(3));
                int newqty = oldqty - Integer.parseInt(txt_jumlah.getText());                  
                String sqll = "UPDATE `barang`" + "SET `stok`='"+newqty+"' WHERE `nama_barang` = '"+txt_namabarang.getText()+"'";
                java.sql.PreparedStatement pstl=conn.prepareStatement(sqll);
                pstl.execute();
                }
        } catch(Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }
    
    public void struk () {
                txt_area.setText(txt_area.getText()+ "\t                Farwas Stationary\n");
        txt_area.setText(txt_area.getText()+ "      Perumahan Griya Mangli Indah Gang DF 8 Wonosari Kaliwates\n");
        txt_area.setText(txt_area.getText()+ "\n");
        txt_area.setText(txt_area.getText()+"Kode Transaksi     "+txt_kodepenjualan.getText()+ "\n");
        txt_area.setText(txt_area.getText()+"Tanggal    "+txt_tanggal.getText() + "\n");
        txt_area.setText(txt_area.getText()+ "----------------------------------------------------------------------------------------------\n");
        DefaultTableModel model = (DefaultTableModel) tablekasir.getModel();
        txt_area.setText(txt_area.getText()+"Nama Barang"+"\t\t"+"Qty"+"                        "+"Harga"+"\t"+"SubTotal"+"\n");
        for(int i =0; i<model.getRowCount(); i++) {
            String item = (String)model.getValueAt(i, 1).toString();
            String Qty = (String)model.getValueAt(i, 2).toString();
            String Harga = (String)model.getValueAt(i, 3).toString();
            String Subtotal = (String)model.getValueAt(i, 4).toString();
        txt_area.setText(txt_area.getText()+item+"\t\t"+Qty+"                           "+Harga+"\t"+Subtotal+"\n");
        }
        txt_area.setText(txt_area.getText()+ "----------------------------------------------------------------------------------------------\n");
        String Total = txt_total.getText();
        String BAYAR = txt_bayarr.getText();
        String KEMBALIAN = txt_kembalian.getText();
        txt_area.setText(txt_area.getText()+"\t                       "+"Total"+"\t"+":"+"\t"+Total+"\n");
        txt_area.setText(txt_area.getText()+"\t                       "+"Bayar"+"\t"+":"+"\t"+BAYAR+"\n");
        txt_area.setText(txt_area.getText()+"\t                       "+"Kembalian"+"\t"+":"+"\t"+KEMBALIAN+"\n");
        txt_area.setText(txt_area.getText()+ "----------------------------------------------------------------------------------------------\n");
        txt_area.setText(txt_area.getText()+ "\n");
        txt_area.setText(txt_area.getText()+ "                  Terimakasih Telah Berbelanja Di Toko Kami");
    }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btn_cetak = new javax.swing.JButton();
        txt_kembalian = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_kodepenjualan = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        btn_cancel = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablekasir = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        txt_total = new javax.swing.JTextField();
        txt_bayarr = new javax.swing.JTextField();
        btn_add = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        btn_tambah = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        txt_namabarang = new javax.swing.JTextField();
        txt_harga = new javax.swing.JTextField();
        txt_jumlah = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        btn_hapus = new javax.swing.JButton();
        txt_tanggal = new javax.swing.JTextField();
        txt_jam = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        btn_logout = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(300, 0));
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        setResizable(false);
        setSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(null);

        btn_cetak.setBackground(new java.awt.Color(108, 52, 68));
        btn_cetak.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_cetak.setForeground(new java.awt.Color(255, 255, 255));
        btn_cetak.setText("Cetak");
        btn_cetak.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_cetak.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_cetak.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_cetak.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cetakActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cetak);
        btn_cetak.setBounds(1380, 860, 130, 40);

        txt_kembalian.setEditable(false);
        txt_kembalian.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_kembalian.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_kembalian);
        txt_kembalian.setBounds(1350, 810, 160, 40);

        txt_user.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        txt_user.setForeground(new java.awt.Color(108, 52, 68));
        txt_user.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        txt_user.setText("USER");
        getContentPane().add(txt_user);
        txt_user.setBounds(1280, 180, 70, 40);

        jLabel5.setFont(new java.awt.Font("Montserrat", 1, 36)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(108, 52, 68));
        jLabel5.setText("TOTAL");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(430, 760, 180, 90);

        jLabel6.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(108, 52, 68));
        jLabel6.setText("Tanggal");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(430, 230, 180, 40);

        jLabel7.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(108, 52, 68));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel7.setText("Bayar");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(1240, 760, 60, 40);

        txt_kodepenjualan.setEditable(false);
        txt_kodepenjualan.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_kodepenjualan.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_kodepenjualan);
        txt_kodepenjualan.setBounds(610, 180, 230, 40);

        jLabel8.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(108, 52, 68));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Kembalian");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(1240, 810, 100, 40);

        btn_cancel.setBackground(new java.awt.Color(108, 52, 68));
        btn_cancel.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_cancel.setForeground(new java.awt.Color(255, 255, 255));
        btn_cancel.setText("Cancel");
        btn_cancel.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_cancel.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_cancel.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_cancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cancelActionPerformed(evt);
            }
        });
        getContentPane().add(btn_cancel);
        btn_cancel.setBounds(1070, 230, 130, 40);

        tablekasir.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        tablekasir.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Kode Barang", "Nama Barang", "Jumlah", "Harga", "Subtotal"
            }
        ));
        tablekasir.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablekasirMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tablekasir);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(430, 400, 1080, 350);

        jLabel9.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(108, 52, 68));
        jLabel9.setText("Kode Penjualan");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(430, 180, 170, 40);

        txt_total.setEditable(false);
        txt_total.setFont(new java.awt.Font("Calibri", 0, 48)); // NOI18N
        txt_total.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_total);
        txt_total.setBounds(560, 760, 660, 90);

        txt_bayarr.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_bayarr.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txt_bayarr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_bayarrActionPerformed(evt);
            }
        });
        txt_bayarr.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_bayarrKeyReleased(evt);
            }
        });
        getContentPane().add(txt_bayarr);
        txt_bayarr.setBounds(1350, 760, 160, 40);

        btn_add.setBackground(new java.awt.Color(108, 52, 68));
        btn_add.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_add.setForeground(new java.awt.Color(255, 255, 255));
        btn_add.setText("Add");
        btn_add.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_add.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_add.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_addActionPerformed(evt);
            }
        });
        getContentPane().add(btn_add);
        btn_add.setBounds(930, 230, 130, 40);

        jPanel1.setBackground(java.awt.Color.orange);
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(245, 202, 33), java.awt.Color.white));
        jPanel1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jPanel1.setDebugGraphicsOptions(javax.swing.DebugGraphics.NONE_OPTION);
        jPanel1.setLayout(null);

        btn_tambah.setBackground(new java.awt.Color(108, 52, 68));
        btn_tambah.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_tambah.setForeground(new java.awt.Color(255, 255, 255));
        btn_tambah.setText("Tambah");
        btn_tambah.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_tambah.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_tambah.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_tambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tambahActionPerformed(evt);
            }
        });
        btn_tambah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                btn_tambahKeyReleased(evt);
            }
        });
        jPanel1.add(btn_tambah);
        btn_tambah.setBounds(710, 40, 130, 40);

        jLabel3.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(108, 52, 68));
        jLabel3.setText("Qty");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(570, 10, 40, 30);

        txt_namabarang.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_namabarang.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txt_namabarang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_namabarangActionPerformed(evt);
            }
        });
        txt_namabarang.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_namabarangKeyReleased(evt);
            }
        });
        jPanel1.add(txt_namabarang);
        txt_namabarang.setBounds(80, 40, 200, 40);

        txt_harga.setEditable(false);
        txt_harga.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_harga.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jPanel1.add(txt_harga);
        txt_harga.setBounds(340, 40, 140, 40);

        txt_jumlah.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_jumlah.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txt_jumlah.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_jumlahKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_jumlahKeyReleased(evt);
            }
        });
        jPanel1.add(txt_jumlah);
        txt_jumlah.setBounds(540, 40, 90, 40);

        jLabel4.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(108, 52, 68));
        jLabel4.setText("Nama Barang");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(120, 10, 140, 30);

        jLabel10.setFont(new java.awt.Font("Montserrat", 1, 20)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(108, 52, 68));
        jLabel10.setText("Harga");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(380, 10, 60, 30);

        btn_hapus.setBackground(new java.awt.Color(108, 52, 68));
        btn_hapus.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_hapus.setForeground(new java.awt.Color(255, 255, 255));
        btn_hapus.setText("Hapus");
        btn_hapus.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_hapus.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_hapus.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_hapus.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_hapusMouseClicked(evt);
            }
        });
        btn_hapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_hapusActionPerformed(evt);
            }
        });
        jPanel1.add(btn_hapus);
        btn_hapus.setBounds(860, 40, 130, 40);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(430, 280, 1080, 110);

        txt_tanggal.setEditable(false);
        txt_tanggal.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_tanggal.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        txt_tanggal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_tanggalActionPerformed(evt);
            }
        });
        getContentPane().add(txt_tanggal);
        txt_tanggal.setBounds(610, 230, 130, 40);

        txt_jam.setEditable(false);
        txt_jam.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txt_jam.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_jam);
        txt_jam.setBounds(750, 230, 90, 40);

        jLabel11.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/logo 380.png"))); // NOI18N
        jLabel11.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel11.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel11.setInheritsPopupMenu(false);
        jLabel11.setMaximumSize(new java.awt.Dimension(620, 140));
        jLabel11.setMinimumSize(new java.awt.Dimension(620, 140));
        jLabel11.setPreferredSize(new java.awt.Dimension(620, 140));
        getContentPane().add(jLabel11);
        jLabel11.setBounds(0, 0, 380, 90);

        txt_userkasir.setEditable(false);
        txt_userkasir.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        getContentPane().add(txt_userkasir);
        txt_userkasir.setBounds(1380, 230, 130, 40);

        txt_userkasir_copy.setEditable(false);
        txt_userkasir_copy.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        getContentPane().add(txt_userkasir_copy);
        txt_userkasir_copy.setBounds(1380, 180, 130, 40);

        btn_logout.setBackground(new java.awt.Color(108, 52, 68));
        btn_logout.setFont(new java.awt.Font("Montserrat", 1, 18)); // NOI18N
        btn_logout.setForeground(new java.awt.Color(255, 255, 255));
        btn_logout.setText("Kembali");
        btn_logout.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_logout.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_logout.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_logout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btn_logoutMouseClicked(evt);
            }
        });
        btn_logout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_logoutActionPerformed(evt);
            }
        });
        getContentPane().add(btn_logout);
        btn_logout.setBounds(1750, 40, 130, 40);

        jLabel1.setFont(new java.awt.Font("Calibri", 1, 48)); // NOI18N
        jLabel1.setText("FORM PENJUALAN");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(770, 80, 380, 50);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Background 1920x1080.png"))); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel2.setMaximumSize(new java.awt.Dimension(1280, 720));
        jLabel2.setMinimumSize(new java.awt.Dimension(1280, 720));
        jLabel2.setPreferredSize(new java.awt.Dimension(1280, 720));
        jLabel2.setRequestFocusEnabled(false);
        jLabel2.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 1920, 1080);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_cetakActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cetakActionPerformed
        // TODO add your handling code here:
        simpandata();
        struk();
        kondisiawal();
        btn_add.setEnabled(true);
        DefaultTableModel model = (DefaultTableModel)tablekasir.getModel();
        model.setRowCount(0);
        try {
        ENotaKasir.txt_area.print();
        } catch (java.awt.print.PrinterException e) {
            System.err.format("Tidak Ada Printer Yang Ditemukan", e.getMessage());
        }
       kosong();
//        txt_bayar.setText(null);
//        txt_kembalian.setText(null);
    }//GEN-LAST:event_btn_cetakActionPerformed

    private void btn_tambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tambahActionPerformed
        munculdata();
        totalsemua();
        pengurangan_stok();
        txt_namabarang.setText(null);
        txt_jumlah.setText(null);
        txt_harga.setText(null);
        txt_namabarang.requestFocus();
        txt_area.setText(null);
    }//GEN-LAST:event_btn_tambahActionPerformed

    private void btn_hapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_hapusActionPerformed

    }//GEN-LAST:event_btn_hapusActionPerformed

    private void txt_tanggalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_tanggalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_tanggalActionPerformed

    private void tablekasirMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablekasirMouseClicked
        int baris = tablekasir.rowAtPoint(evt.getPoint());
        String kode_penjualan = txt_kodepenjualan.getText();
        txt_kodepenjualan.setText(kode_penjualan);
        txt_kodepenjualan.disable();
        if (tablekasir.getValueAt(baris, 1)==null) {
            txt_namabarang.setText("");
        } else {
            txt_namabarang.setText(tablekasir.getValueAt(baris, 1).toString());
        }
        if (tablekasir.getValueAt(baris, 2)==null) {
            txt_jumlah.setText("");
        } else {
            txt_jumlah.setText(tablekasir.getValueAt(baris, 2).toString());
        }
        if (tablekasir.getValueAt(baris, 3)==null) {
            txt_harga.setText("");
        } else {
            txt_harga.setText(tablekasir.getValueAt(baris, 3).toString());
        }

    }//GEN-LAST:event_tablekasirMouseClicked

    private void btn_addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_addActionPerformed
        // TODO add your handling code here:
        aktif();
        invoiceid();
        btn_add.setEnabled(false);
        txt_namabarang.requestFocus();
    }//GEN-LAST:event_btn_addActionPerformed

    private void btn_cancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cancelActionPerformed
        // TODO add your handling code here:
        kosong();
        kondisiawal();
        btn_add.setEnabled(true);

    }//GEN-LAST:event_btn_cancelActionPerformed

    private void txt_namabarangKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_namabarangKeyReleased
        try {

                String sql = "select * from barang where nama_barang='"+txt_namabarang.getText()+"'";
                java.sql.Connection conn=(Connection)Connect.configDB();
                java.sql.Statement stm=conn.createStatement();
                java.sql.ResultSet res=stm.executeQuery(sql);
                while(res.next()) {
                txt_harga.setText(res.getString("harga_jual"));
                }            
        } catch (Exception e) {
        }
        if (txt_namabarang.getText().equals("")) {
            txt_harga.setText(null);
        }
        
    }//GEN-LAST:event_txt_namabarangKeyReleased

    private void txt_bayarrKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_bayarrKeyReleased
        kembalian();
    }//GEN-LAST:event_txt_bayarrKeyReleased

    private void btn_tambahKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_btn_tambahKeyReleased

    }//GEN-LAST:event_btn_tambahKeyReleased

    private void txt_jumlahKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_jumlahKeyReleased

    }//GEN-LAST:event_txt_jumlahKeyReleased

    private void txt_jumlahKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_jumlahKeyPressed

    }//GEN-LAST:event_txt_jumlahKeyPressed

    private void btn_logoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_logoutMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_btn_logoutMouseClicked

    private void btn_logoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_logoutActionPerformed
        try {
            String sql = "SELECT * FROM user WHERE username='"+txt_username.getText()
                  +"'AND password='"+txt_password.getText()+"'";
            java.sql.Connection conn=(Connection)Connect.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            java.sql.ResultSet rs = pst.executeQuery(sql);
            
            if (rs.next()){
                String hak_akses = rs.getString("hak_akses");
                if (hak_akses.equals("Admin")){
                    new MenuTransaksi().setVisible(true);
                    this.dispose();
                }else if (hak_akses.equals("Kasir")){
                    new login().setVisible(true);
                    this.dispose();
                }
            }
            
            if (rs.next()) {
                if (txt_username.getText().equals(rs.getString("username"))
                    && txt_password.getText().equals(rs.getString("password"))) {

                    this.setVisible(false);
                    new MenuUtama().setVisible(true);   
                    
               } 
          } else {

           }
    
       } catch (Exception e) {

        }
    }//GEN-LAST:event_btn_logoutActionPerformed

    private void txt_bayarrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_bayarrActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_bayarrActionPerformed

    private void btn_hapusMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_hapusMouseClicked
        DefaultTableModel model = (DefaultTableModel) tablekasir.getModel();
        try {
            int rs[] = tablekasir.getSelectedRows();
            for (int i=0; i<rs.length; i++) {
                String sql = "select * from barang where nama_barang ='"+model.getValueAt(i, 1).toString()+"'";
                java.sql.Connection conn=(Connection)Connect.configDB();
                java.sql.Statement stm=conn.createStatement();
                java.sql.ResultSet res=stm.executeQuery(sql);  
                while (res.next()) {
                int oldqty = Integer.parseInt(res.getString(3));
                int newqty = oldqty + Integer.parseInt(model.getValueAt(i, 2).toString());                  
                String sqll = "UPDATE `barang`" + "SET `stok`='"+newqty+"' WHERE `nama_barang` = '"+model.getValueAt(i, 1).toString()+"'";
                java.sql.PreparedStatement pstl=conn.prepareStatement(sqll);
                pstl.execute();                        
                    }
                }
        } catch(Exception e) {

        }
        int[] rows = tablekasir.getSelectedRows();
        for(int i=0;i<rows.length;i++){
            model.removeRow(rows[i]-i);
        }
        
        if  (tablekasir.getRowCount()==0) {
            txt_total.setText("0");
            txt_bayarr.setText("0");
            txt_kembalian.setText("0");
        }
        totalsemua();
    }//GEN-LAST:event_btn_hapusMouseClicked

    private void txt_namabarangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_namabarangActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_txt_namabarangActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Kasir.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Kasir().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_add;
    private javax.swing.JButton btn_cancel;
    private javax.swing.JButton btn_cetak;
    private javax.swing.JButton btn_hapus;
    private javax.swing.JButton btn_logout;
    private javax.swing.JButton btn_tambah;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private static javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablekasir;
    private javax.swing.JTextField txt_bayarr;
    private javax.swing.JTextField txt_harga;
    private javax.swing.JTextField txt_jam;
    private javax.swing.JTextField txt_jumlah;
    private javax.swing.JTextField txt_kembalian;
    private javax.swing.JTextField txt_kodepenjualan;
    private javax.swing.JTextField txt_namabarang;
    private javax.swing.JTextField txt_tanggal;
    private javax.swing.JTextField txt_total;
    public static final javax.swing.JLabel txt_user = new javax.swing.JLabel();
    public static final javax.swing.JTextField txt_userkasir = new javax.swing.JTextField();
    public static final javax.swing.JTextField txt_userkasir_copy = new javax.swing.JTextField();
    // End of variables declaration//GEN-END:variables
}
