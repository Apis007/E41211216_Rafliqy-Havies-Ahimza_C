package farwas;
import java.awt.Color;
import java.sql.Connection;
import javax.swing.JOptionPane;
import static farwas.MenuUtama.juser;
import static farwas.MenuUtama.jakses;
import static farwas.Kasir.txt_user;
import static farwas.Kasir.txt_userkasir;
import static farwas.Kasir.txt_userkasir_copy;
import static farwas.Pembelian.txt_kodeuserpembelian;
import static farwas.Pembelian.txt_namauserpembelian;
public class login extends javax.swing.JFrame {

    public login() {
        initComponents();
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        btn_login = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        logouser = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setMaximumSize(new java.awt.Dimension(300, 50));
        jLabel1.setMinimumSize(new java.awt.Dimension(300, 50));
        jLabel1.setPreferredSize(new java.awt.Dimension(300, 50));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(300, 0));
        setMaximumSize(new java.awt.Dimension(1920, 1080));
        setMinimumSize(new java.awt.Dimension(1920, 1080));
        setResizable(false);
        setSize(new java.awt.Dimension(1920, 1080));
        getContentPane().setLayout(null);

        txt_username.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        txt_username.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        getContentPane().add(txt_username);
        txt_username.setBounds(880, 560, 260, 40);

        txt_password.setFont(new java.awt.Font("Calibri", 1, 18)); // NOI18N
        txt_password.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txt_passwordKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_passwordKeyReleased(evt);
            }
        });
        getContentPane().add(txt_password);
        txt_password.setBounds(880, 620, 260, 40);

        btn_login.setBackground(new java.awt.Color(108, 52, 68));
        btn_login.setFont(new java.awt.Font("Montserrat", 1, 24)); // NOI18N
        btn_login.setForeground(new java.awt.Color(255, 255, 255));
        btn_login.setText("LOGIN");
        btn_login.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        btn_login.setMaximumSize(new java.awt.Dimension(160, 40));
        btn_login.setMinimumSize(new java.awt.Dimension(160, 40));
        btn_login.setPreferredSize(new java.awt.Dimension(160, 40));
        btn_login.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn_loginMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn_loginMouseExited(evt);
            }
        });
        btn_login.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_loginActionPerformed(evt);
            }
        });
        getContentPane().add(btn_login);
        btn_login.setBounds(900, 690, 210, 40);

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/akun.png"))); // NOI18N
        getContentPane().add(jLabel6);
        jLabel6.setBounds(900, 360, 190, 190);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/padlock.png"))); // NOI18N
        jLabel5.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jLabel5.setMaximumSize(new java.awt.Dimension(260, 30));
        jLabel5.setMinimumSize(new java.awt.Dimension(260, 30));
        jLabel5.setPreferredSize(new java.awt.Dimension(260, 30));
        getContentPane().add(jLabel5);
        jLabel5.setBounds(790, 620, 70, 70);

        logouser.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        logouser.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/login2.png"))); // NOI18N
        logouser.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        logouser.setMaximumSize(new java.awt.Dimension(260, 30));
        logouser.setMinimumSize(new java.awt.Dimension(260, 30));
        logouser.setPreferredSize(new java.awt.Dimension(260, 30));
        getContentPane().add(logouser);
        logouser.setBounds(780, 540, 70, 70);

        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Logo.png"))); // NOI18N
        jLabel3.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel3.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel3.setInheritsPopupMenu(false);
        jLabel3.setMaximumSize(new java.awt.Dimension(620, 140));
        jLabel3.setMinimumSize(new java.awt.Dimension(620, 140));
        jLabel3.setPreferredSize(new java.awt.Dimension(620, 140));
        getContentPane().add(jLabel3);
        jLabel3.setBounds(630, 150, 680, 210);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/farwas/img/Background 1920x1080.png"))); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jLabel2.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel2.setMaximumSize(new java.awt.Dimension(1920, 1080));
        jLabel2.setMinimumSize(new java.awt.Dimension(1920, 1080));
        jLabel2.setPreferredSize(new java.awt.Dimension(1920, 1080));
        jLabel2.setRequestFocusEnabled(false);
        jLabel2.setVerifyInputWhenFocusTarget(false);
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 1920, 1080);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btn_loginActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_loginActionPerformed

        try {
            String sql = "SELECT * FROM user WHERE username='"+txt_username.getText()
                  +"'AND password='"+txt_password.getText()+"'";
            java.sql.Connection conn=(Connection)Connect.configDB();
            java.sql.PreparedStatement pst=conn.prepareStatement(sql);
            java.sql.ResultSet rs = pst.executeQuery(sql);
            
            if (rs.next()){
                String hak_akses = rs.getString("hak_akses");
                if (hak_akses.equals("Admin")){
                    new MenuUtama().setVisible(true);
                    this.dispose();
                    juser.setText(rs.getString(2));
                    jakses.setText(rs.getString(5));
                    txt_userkasir.setText(rs.getString(1));
                    txt_userkasir_copy.setText(rs.getString(2));
                    txt_userkasir_copy.setText(rs.getString(2));
                    txt_kodeuserpembelian.setText(rs.getString(1));
                    txt_namauserpembelian.setText(rs.getString(2));
                }else if (hak_akses.equals("Kasir")){
                    new Kasir().setVisible(true);
                    txt_userkasir.setText(rs.getString(1));
                    txt_userkasir_copy.setText(rs.getString(2));
                    txt_kodeuserpembelian.setText(rs.getString(1));
                    txt_namauserpembelian.setText(rs.getString(2));
                    this.dispose();                    
                }            
               JOptionPane.showMessageDialog(this, "Berhasil Login");   
          } else {
               JOptionPane.showMessageDialog(this,
                        "Username atau Password Salah");
           }
    
       } catch (Exception e) {
           JOptionPane.showMessageDialog(this, e.getMessage());
        }
        
    }//GEN-LAST:event_btn_loginActionPerformed

    private void btn_loginMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_loginMouseEntered
        btn_login.setBackground(new Color(75,36,47));
    }//GEN-LAST:event_btn_loginMouseEntered

    private void btn_loginMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btn_loginMouseExited
        btn_login.setBackground(new Color(108,52,68));
    }//GEN-LAST:event_btn_loginMouseExited

    private void txt_passwordKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_passwordKeyPressed
              
    }//GEN-LAST:event_txt_passwordKeyPressed

    private void txt_passwordKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_passwordKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_passwordKeyReleased

    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
       java.awt.EventQueue.invokeLater(new Runnable() {
           public void run() {
               new login().setVisible(true);
           }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_login;
    private javax.swing.JLabel jLabel1;
    private static javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel logouser;
    public static final javax.swing.JPasswordField txt_password = new javax.swing.JPasswordField();
    public static final javax.swing.JTextField txt_username = new javax.swing.JTextField();
    // End of variables declaration//GEN-END:variables
}
